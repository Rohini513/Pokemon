import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create a route to proxy PokeAPI requests to avoid CORS issues
  app.get("/api/pokemon", async (req, res) => {
    try {
      const limit = req.query.limit || 150;
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${limit}`);
      
      if (!response.ok) {
        throw new Error(`PokeAPI responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Error fetching Pokemon list:", error);
      res.status(500).json({ 
        error: "Failed to fetch Pokemon data",
        message: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/pokemon/:idOrName", async (req, res) => {
    try {
      const { idOrName } = req.params;
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${idOrName}`);
      
      if (!response.ok) {
        throw new Error(`PokeAPI responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error(`Error fetching Pokemon ${req.params.idOrName}:`, error);
      res.status(500).json({ 
        error: "Failed to fetch Pokemon data",
        message: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
