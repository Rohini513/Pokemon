import React, { useState } from "react";
import Layout from "@/components/Layout";
import SearchBar from "@/components/SearchBar";
import TypeFilter from "@/components/TypeFilter";
import PokemonList from "@/components/PokemonList";
import { usePokemonData } from "@/hooks/usePokemonData";
import { PokemonTypeOption } from "@/lib/types";

const Home: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState<PokemonTypeOption>("all");
  
  const { pokemons, isLoading, error } = usePokemonData();

  return (
    <Layout>
      <section className="mb-10">
        <div className="text-center mb-8">
          <h1 className="font-pokemon text-3xl md:text-4xl text-gray-800 mb-4">
            Pokémon Explorer
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Search and filter through the original 150 Pokémon from the Kanto region.
            Find your favorites by name or type!
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
          <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
          <TypeFilter selectedType={selectedType} setSelectedType={setSelectedType} />
        </div>

        {error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md text-center">
            <p>Error loading Pokémon data: {error.message}</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-2 bg-red-600 text-white px-4 py-2 rounded-md text-sm hover:bg-red-700"
            >
              Try Again
            </button>
          </div>
        ) : (
          <PokemonList 
            pokemons={pokemons} 
            isLoading={isLoading} 
            searchTerm={searchTerm}
            selectedType={selectedType}
          />
        )}
      </section>
    </Layout>
  );
};

export default Home;
