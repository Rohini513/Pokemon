import React from "react";

export function Pokeball({ className = "" }: { className?: string }) {
  return (
    <div className={`relative animate-shake ${className}`}>
      <div className="relative w-6 h-6 bg-gradient-to-b from-primary to-primary via-primary to-50% from-white via-white from-50% rounded-full border-2 border-gray-800">
        <div className="absolute bg-white w-2 h-2 rounded-full top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 border-2 border-gray-800"></div>
      </div>
    </div>
  );
}

export default Pokeball;
