import React from "react";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Pokemon } from "@/lib/types";

interface PokemonCardProps {
  pokemon: Pokemon;
  isLoading: boolean;
}

const PokemonCard: React.FC<PokemonCardProps> = ({ pokemon, isLoading }) => {
  if (isLoading) {
    return (
      <Card className="h-full overflow-hidden transition-all duration-300 hover:shadow-md">
        <CardHeader className="p-4 pb-0">
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-4 w-12 mt-2" />
        </CardHeader>
        <CardContent className="p-4 flex justify-center">
          <Skeleton className="h-36 w-36 rounded-md" />
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-start gap-2">
          <Skeleton className="h-6 w-16 rounded-full" />
        </CardFooter>
      </Card>
    );
  }

  // Format Pokémon ID to display as #001, #010, #100 etc.
  const formattedId = `#${pokemon.id.toString().padStart(3, "0")}`;
  
  // Get official artwork if available, fallback to default sprite
  const imageUrl = 
    pokemon.sprites.other["official-artwork"].front_default || 
    pokemon.sprites.front_default;

  // Capitalize the first letter of the Pokémon name
  const capitalizedName = pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1);

  return (
    <Card className="h-full overflow-hidden transition-all duration-300 hover:shadow-md hover:-translate-y-1">
      <CardHeader className="p-4 pb-0">
        <div className="flex justify-between items-start">
          <h2 className="text-lg font-semibold">{capitalizedName}</h2>
          <span className="text-sm text-gray-500 font-mono">{formattedId}</span>
        </div>
      </CardHeader>
      <CardContent className="p-4 flex justify-center">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={pokemon.name} 
            className="h-36 w-36 object-contain"
            loading="lazy"
          />
        ) : (
          <div className="h-36 w-36 flex items-center justify-center bg-gray-100 rounded-md">
            <span className="text-gray-400">No image</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="p-4 pt-0 flex flex-wrap gap-2">
        {pokemon.types.map((typeInfo) => (
          <Badge 
            key={typeInfo.type.name} 
            className={`type-${typeInfo.type.name} text-white capitalize`}
          >
            {typeInfo.type.name}
          </Badge>
        ))}
      </CardFooter>
    </Card>
  );
};

export default PokemonCard;
