import React from "react";
import Pokeball from "./Pokeball";

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <div className="flex items-center">
            <Pokeball className="mr-3" />
            <h1 className="font-pokemon text-lg md:text-xl text-gray-800">PokéSearch</h1>
          </div>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 py-8">
        {children}
      </main>

      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">
            Data from{" "}
            <a
              href="https://pokeapi.co/"
              target="_blank"
              rel="noreferrer"
              className="text-primary hover:underline"
            >
              PokéAPI
            </a>{" "}
            | Pokémon and Pokémon character names are trademarks of Nintendo.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
