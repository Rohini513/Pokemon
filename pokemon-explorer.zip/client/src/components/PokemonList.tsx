import React from "react";
import PokemonCard from "./PokemonCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Pokemon, PokemonTypeOption } from "@/lib/types";

interface PokemonListProps {
  pokemons: Pokemon[];
  isLoading: boolean;
  searchTerm: string;
  selectedType: PokemonTypeOption;
}

const PokemonList: React.FC<PokemonListProps> = ({
  pokemons,
  isLoading,
  searchTerm,
  selectedType,
}) => {
  // Filter based on search term and selected type
  const filteredPokemons = pokemons.filter((pokemon) => {
    const matchesSearch = pokemon.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = 
      selectedType === "all" || 
      pokemon.types.some((typeInfo) => typeInfo.type.name === selectedType);
    
    return matchesSearch && matchesType;
  });

  // Loading skeletons
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {Array.from({ length: 12 }).map((_, index) => (
          <div key={index}>
            <PokemonCard pokemon={{} as Pokemon} isLoading={true} />
          </div>
        ))}
      </div>
    );
  }

  // Empty state when no matches
  if (filteredPokemons.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-10 text-center">
        <div className="w-24 h-24 mb-4 opacity-50">
          <img 
            src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" 
            alt="Empty Pokeball" 
            className="w-full h-full"
          />
        </div>
        <h3 className="text-xl font-bold mb-2">No Pokémon Found!</h3>
        <p className="text-gray-500 max-w-md">
          {searchTerm && selectedType !== "all"
            ? `No Pokémon matching "${searchTerm}" with type "${selectedType}".`
            : searchTerm
            ? `No Pokémon matching "${searchTerm}".`
            : selectedType !== "all"
            ? `No Pokémon with type "${selectedType}".`
            : "No Pokémon available."}
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {filteredPokemons.map((pokemon) => (
        <PokemonCard key={pokemon.id} pokemon={pokemon} isLoading={false} />
      ))}
    </div>
  );
};

export default PokemonList;
