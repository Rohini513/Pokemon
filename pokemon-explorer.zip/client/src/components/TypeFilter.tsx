import React from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PokemonTypeOption } from "@/lib/types";

interface TypeFilterProps {
  selectedType: PokemonTypeOption;
  setSelectedType: (value: PokemonTypeOption) => void;
}

const TypeFilter: React.FC<TypeFilterProps> = ({
  selectedType,
  setSelectedType,
}) => {
  const pokemonTypes: PokemonTypeOption[] = [
    "all",
    "normal",
    "fire",
    "water",
    "grass",
    "electric",
    "ice",
    "fighting",
    "poison",
    "ground",
    "flying",
    "psychic",
    "bug",
    "rock",
    "ghost",
    "dark",
    "dragon",
    "steel",
    "fairy",
  ];

  return (
    <div className="w-full max-w-xs">
      <Select
        value={selectedType}
        onValueChange={(value) => setSelectedType(value as PokemonTypeOption)}
      >
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Filter by type" />
        </SelectTrigger>
        <SelectContent>
          {pokemonTypes.map((type) => (
            <SelectItem key={type} value={type} className="capitalize">
              {type === "all" ? "All Types" : type}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default TypeFilter;
