import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Pokemon, PokemonListResponse } from "@/lib/types";

// Hook for fetching Pokemon data
export function usePokemonData() {
  const [pokemons, setPokemons] = useState<Pokemon[]>([]);

  // Fetch the first 150 Pokemon
  const { data: pokemonList, isLoading: isListLoading, error: listError } = useQuery({
    queryKey: ["pokemonList"],
    queryFn: async () => {
      const response = await fetch("https://pokeapi.co/api/v2/pokemon?limit=150");
      if (!response.ok) {
        throw new Error("Failed to fetch Pokemon list");
      }
      return response.json() as Promise<PokemonListResponse>;
    },
  });

  // Fetch details for each Pokemon once we have the list
  const { isLoading: isDetailsLoading, error: detailsError } = useQuery({
    queryKey: ["pokemonDetails", pokemonList?.results],
    enabled: !!pokemonList?.results,
    queryFn: async () => {
      if (!pokemonList?.results) return null;

      try {
        // Fetch all Pokemon details in parallel
        const detailsPromises = pokemonList.results.map(async (pokemon) => {
          const response = await fetch(pokemon.url);
          if (!response.ok) {
            throw new Error(`Failed to fetch details for ${pokemon.name}`);
          }
          return response.json() as Promise<Pokemon>;
        });

        // Wait for all promises to resolve
        const details = await Promise.all(detailsPromises);
        // Sort by ID to maintain original order
        details.sort((a, b) => a.id - b.id);
        setPokemons(details);
        return details;
      } catch (error) {
        console.error("Error fetching Pokemon details:", error);
        throw error;
      }
    },
  });

  const isLoading = isListLoading || isDetailsLoading;
  const error = listError || detailsError;

  return {
    pokemons,
    isLoading,
    error,
  };
}
