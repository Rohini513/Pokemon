# Pokémon Explorer Application

This is an interactive React application that allows users to search and filter through the first 150 Pokémon using data from the PokeAPI.

## Features

- Browse through the original 150 Pokémon from the Kanto region
- Search Pokémon by name
- Filter Pokémon by type
- Responsive design for mobile and desktop

## Running the Application Locally

### Prerequisites

- Node.js (version 16.x or higher)
- npm (comes with Node.js)

### Installation Steps

1. Extract the downloaded folder to a location on your computer
2. Open a terminal/command prompt and navigate to the extracted folder
3. Install dependencies:
   ```
   npm install
   ```
4. Start the development server:
   ```
   npm run dev
   ```
5. Open your browser and navigate to:
   ```
   http://localhost:5000
   ```

## Project Structure

- `client/` - Frontend React application
  - `src/` - Source code for the React app
    - `components/` - Reusable UI components
    - `hooks/` - Custom React hooks
    - `lib/` - Utility functions and type definitions
    - `pages/` - Page components
- `server/` - Backend Express server
- `shared/` - Shared code between frontend and backend

## Technologies Used

- React with TypeScript
- Express.js for the backend
- TanStack Query for data fetching
- Tailwind CSS with shadcn/ui components
- PokeAPI for Pokémon data

## Credits

- Data from [PokeAPI](https://pokeapi.co/)
- Pokémon and Pokémon character names are trademarks of Nintendo